package com.plourlbackend.domain;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

import org.springframework.data.annotation.Id;

@Entity
@Table(name = "Tracking")
public class Tracking {
	@Id
	@Column(name = "id", unique = true, nullable = false)
	private Integer id;
	
	@JoinColumn(name = "id_service_request", nullable = false)
	private Service service;
	
	@Column(name = "latitude")
	private long latitude;
	
	@Column (name = "longitude")
	private long longitude;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Service getService() {
		return service;
	}

	public void setService(Service service) {
		this.service = service;
	}

	public long getLatitude() {
		return latitude;
	}

	public void setLatitude(long latitude) {
		this.latitude = latitude;
	}

	public long getLongitude() {
		return longitude;
	}

	public void setLongitude(long longitude) {
		this.longitude = longitude;
	}

	public Tracking(Integer id, Service service, long latitude, long longitude) {
		this.id = id;
		this.service = service;
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	public Tracking() {}

	@Override
	public String toString() {
		return "Tracking [id=" + id + ", service=" + service + ", latitude=" + latitude + ", longitude=" + longitude
				+ "]";
	}
	
	
	
	
		
}
