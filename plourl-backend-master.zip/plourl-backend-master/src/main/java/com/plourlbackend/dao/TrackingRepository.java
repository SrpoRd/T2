package com.plourlbackend.dao;

import org.springframework.data.repository.CrudRepository;

import com.plourlbackend.domain.Tracking;

public interface TrackingRepository extends CrudRepository<Tracking,Integer>{
	//ToDO : Add method get user by package --camel sense query
}
