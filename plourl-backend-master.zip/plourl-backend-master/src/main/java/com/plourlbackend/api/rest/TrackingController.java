package com.plourlbackend.api.rest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.plourlbackend.domain.Service;
import com.plourlbackend.domain.Tracking;
import com.plourlbackend.service.TrackingService;

@RestController
@RequestMapping(value = "/api/plourl/tracking")
public class TrackingController extends AbstractRestHandler {
	
	@Autowired
	private TrackingService trackingService;
	
	@RequestMapping(method=RequestMethod.GET ,value="/{id}")
	public Tracking getTracking(@PathVariable("id") Integer id)
	{
		Tracking tracking = this.getTracking(id);
		checkResourceFound(tracking);
		return tracking;
	}
	
	@RequestMapping(method=RequestMethod.PUT ,value="/{id}",
			consumes = {"application/json", "application/xml"},
            produces = {"application/json", "application/xml"})
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void UpdateTracking(@PathVariable("id") Integer id,
			@RequestBody Tracking tracking,
			HttpServletRequest request, HttpServletResponse response
			)
	{
		Tracking _updateTrackingInformation = this.trackingService.getTracking(id);
		checkResourceFound(_updateTrackingInformation);
		this.trackingService.updateTracking(_updateTrackingInformation);
	}

}
