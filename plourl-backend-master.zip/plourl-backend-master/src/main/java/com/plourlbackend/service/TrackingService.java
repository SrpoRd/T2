package com.plourlbackend.service;

import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.plourlbackend.dao.TrackingRepository;

import com.plourlbackend.domain.Tracking;
import com.plourlbackend.domain.User;


@Service
public class TrackingService {
	
	 private static final Logger log = LoggerFactory.getLogger(Tracking.class);
	
    private  TrackingRepository trackingRepository;

    @Autowired
    public void trackingService(TrackingRepository trackingRepository) {
        this.trackingRepository = trackingRepository;
    }

    public Tracking createTracking(Tracking tracking) {
        return trackingRepository.save(tracking);
    }

    public Tracking getTracking(Integer id) {
        return trackingRepository.findOne(id);
    }

    public Tracking updateTracking(Tracking tracking) {
        return trackingRepository.save(tracking);
    }

    public Tracking deleteTracking(Integer id) {
        Optional<Tracking> traking = Optional.ofNullable(trackingRepository.findOne(id));
        if (traking.isPresent()) {
            trackingRepository.delete(id);
            return traking.get();
        } else {
            throw new IllegalArgumentException("El recurso solicitado no existe");
        }
    }

}
