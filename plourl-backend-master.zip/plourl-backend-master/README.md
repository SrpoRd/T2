# plourl-backend


Para ejecutar el proyecto utilizar el siguiente comando:

```
mvn spring-boot:run -Drun.arguments="spring.profiles.active=test"
```

Previamente se requiere tener instalado Maven

Nota: En el gradle.properties se encuentran los datos de conexión