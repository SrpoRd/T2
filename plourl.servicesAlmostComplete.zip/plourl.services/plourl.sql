-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 01-11-2017 a las 19:51:33
-- Versión del servidor: 10.1.28-MariaDB
-- Versión de PHP: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `plourl`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `availabilities`
--

CREATE TABLE `availabilities` (
  `id` int(11) NOT NULL,
  `departure` datetime DEFAULT NULL,
  `height` float DEFAULT NULL,
  `width` float DEFAULT NULL,
  `depth` float DEFAULT NULL,
  `destination` int(11) DEFAULT NULL,
  `driver` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `destinations`
--

CREATE TABLE `destinations` (
  `idDESTINATIONS` int(11) NOT NULL,
  `state` varchar(45) NOT NULL,
  `city` varchar(45) NOT NULL,
  `address` varchar(45) NOT NULL,
  `user` varchar(45) NOT NULL,
  `lat` double NOT NULL,
  `long` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `destinations`
--

INSERT INTO `destinations` (`idDESTINATIONS`, `state`, `city`, `address`, `user`, `lat`, `long`) VALUES
(1, 'prueba', 'Medellin', 'calle falsa ', '1', 4789, 852),
(2, 'Colombia', 'Medellin', 'calle falsa ', '1', 4789, 852),
(60, 'Colombia', 'Medellin', 'calle falsa ', '1', 4789, 852),
(61, 'Colombia', 'Medellin', 'calle falsa ', '2', 4789, 852),
(62, 'Colombia', 'Medellin', 'calle falsa ', '62', 4789, 852),
(64, 'prueba', 'Medellin', 'calle falsa ', '1', 4789, 852);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `notifications`
--

CREATE TABLE `notifications` (
  `id` int(11) NOT NULL,
  `from` varchar(45) NOT NULL,
  `to` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  `description` varchar(280) NOT NULL,
  `link_details` varchar(280) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `offers`
--

CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `status` varchar(45) NOT NULL,
  `value` decimal(10,0) NOT NULL,
  `request` int(11) NOT NULL,
  `driver` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `packages`
--

CREATE TABLE `packages` (
  `id` int(11) NOT NULL,
  `height` float NOT NULL,
  `width` float NOT NULL,
  `depth` float NOT NULL,
  `content` varchar(140) NOT NULL,
  `recomendation` varchar(140) DEFAULT NULL,
  `request` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `packagess`
--

CREATE TABLE `packagess` (
  `content` varchar(140) NOT NULL,
  `depth` int(11) NOT NULL,
  `height` double NOT NULL,
  `id` int(11) NOT NULL,
  `recomendation` varchar(140) NOT NULL,
  `request` int(11) NOT NULL,
  `width` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `packagess`
--

INSERT INTO `packagess` (`content`, `depth`, `height`, `id`, `recomendation`, `request`, `width`) VALUES
('Galletas dhjkdqwhjkdq', 1234, 2550, 64, 'si', 0, 4520);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ratings`
--

CREATE TABLE `ratings` (
  `idRATINGS` int(11) NOT NULL,
  `who` varchar(45) NOT NULL,
  `whom` varchar(45) NOT NULL,
  `service` varchar(45) NOT NULL,
  `value` int(11) NOT NULL,
  `comment` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `user` varchar(45) NOT NULL,
  `departure` varchar(20) NOT NULL,
  `destination` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `requests`
--

INSERT INTO `requests` (`id`, `user`, `departure`, `destination`) VALUES
(1, '1', '2017-10-19', 1),
(40, '50', '2017-10-12', 60),
(41, '51', '2017-10-12', 61),
(62, '62', '2017-10-12', 62),
(64, '1', '2017-10-19', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `services`
--

CREATE TABLE `services` (
  `id` int(11) NOT NULL,
  `driver` varchar(45) NOT NULL,
  `offer` int(11) NOT NULL,
  `status` varchar(45) NOT NULL,
  `availability` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `trackings`
--

CREATE TABLE `trackings` (
  `id` int(11) NOT NULL,
  `service` int(11) DEFAULT NULL,
  `lat` double DEFAULT NULL,
  `long` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `users`
--

CREATE TABLE `users` (
  `id` varchar(20) NOT NULL,
  `name` varchar(45) NOT NULL,
  `lastname` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `mobile` varchar(45) NOT NULL,
  `photo_url` varchar(120) DEFAULT NULL,
  `type` varchar(45) NOT NULL,
  `correo` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `users`
--

INSERT INTO `users` (`id`, `name`, `lastname`, `phone`, `mobile`, `photo_url`, `type`, `correo`) VALUES
('1', 'Santiago', 'Restrepo9066', '30', '40', '50', '20', '60'),
('15', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('16', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('17', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('2', 'Santiago', 'Res', '1234', '2344', '12233', '31', ''),
('3', 'Santiago', 'Res', '1234', '2344', '12233', '31', ''),
('4', 'Santiago', 'Res', '1234', '2344', '12233', '31', ''),
('50', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('51', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('52', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('54', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('60', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('61', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('62', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('63', 'santiago', 'Restrepo', '4550', '8545', 'http:null', 'user', 'notiene@xyz.com'),
('64', 'Santiago', 'Restrepo9066', '30', '40', '50', '20', '60');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `availabilities`
--
ALTER TABLE `availabilities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `destination_id_idx` (`destination`),
  ADD KEY `driver_id_idx` (`driver`);

--
-- Indices de la tabla `destinations`
--
ALTER TABLE `destinations`
  ADD PRIMARY KEY (`idDESTINATIONS`),
  ADD KEY `user_id_idx` (`user`);

--
-- Indices de la tabla `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notification_to_id_idx` (`to`),
  ADD KEY `notification_from_id_idx` (`from`);

--
-- Indices de la tabla `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_idx` (`request`),
  ADD KEY `driver_idx` (`driver`);

--
-- Indices de la tabla `packages`
--
ALTER TABLE `packages`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `request` (`request`),
  ADD KEY `request_idx` (`request`),
  ADD KEY `request_2` (`request`);

--
-- Indices de la tabla `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`idRATINGS`),
  ADD KEY `who_user_idx` (`who`),
  ADD KEY `whom_user_idx` (`whom`);

--
-- Indices de la tabla `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_idx` (`user`),
  ADD KEY `destination_idx` (`destination`);

--
-- Indices de la tabla `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`),
  ADD KEY `service_driver_id_idx` (`driver`),
  ADD KEY `service_offer_id_idx` (`offer`),
  ADD KEY `service_availability_id_idx` (`availability`);

--
-- Indices de la tabla `trackings`
--
ALTER TABLE `trackings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `tracking_service_id_idx` (`service`);

--
-- Indices de la tabla `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `destinations`
--
ALTER TABLE `destinations`
  MODIFY `idDESTINATIONS` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT de la tabla `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `ratings`
--
ALTER TABLE `ratings`
  MODIFY `idRATINGS` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `availabilities`
--
ALTER TABLE `availabilities`
  ADD CONSTRAINT `destination_id_availability` FOREIGN KEY (`destination`) REFERENCES `destinations` (`idDESTINATIONS`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `driver_id_availablity` FOREIGN KEY (`driver`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `destinations`
--
ALTER TABLE `destinations`
  ADD CONSTRAINT `user_id` FOREIGN KEY (`user`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notification_from_id` FOREIGN KEY (`from`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `notification_to_id` FOREIGN KEY (`to`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `offers`
--
ALTER TABLE `offers`
  ADD CONSTRAINT `driver_id` FOREIGN KEY (`driver`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `request_id` FOREIGN KEY (`request`) REFERENCES `requests` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `packages`
--
ALTER TABLE `packages`
  ADD CONSTRAINT `request` FOREIGN KEY (`request`) REFERENCES `requests` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `who_user` FOREIGN KEY (`who`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `whom_user` FOREIGN KEY (`whom`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `requests`
--
ALTER TABLE `requests`
  ADD CONSTRAINT `destination` FOREIGN KEY (`destination`) REFERENCES `destinations` (`idDESTINATIONS`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `user` FOREIGN KEY (`user`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `services`
--
ALTER TABLE `services`
  ADD CONSTRAINT `service_availability_id` FOREIGN KEY (`availability`) REFERENCES `availabilities` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `service_driver_id` FOREIGN KEY (`driver`) REFERENCES `users` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `service_offer_id` FOREIGN KEY (`offer`) REFERENCES `offers` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `trackings`
--
ALTER TABLE `trackings`
  ADD CONSTRAINT `tracking_service_id` FOREIGN KEY (`service`) REFERENCES `services` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
