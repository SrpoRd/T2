package com.plourl.services.domain;

public class packages {
    private   Integer id;
    private  float height;
    private  float width;
    private  float depth;
    private  String content;
    private String recomendations;

    public packages(Integer id, float height, float width, float depth, String content, String recomendations) {
        this.id = id;
        this.height = height;
        this.width = width;
        this.depth = depth;
        this.content = content;
        this.recomendations = recomendations;
    }

    public  packages(){}

    public void setId(Integer id) {
        this.id = id;
    }

    public void setHeight(float height) {
        this.height = height;
    }

    public void setWidth(float width) {
        this.width = width;
    }

    public void setDepth(float depth) {
        this.depth = depth;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public void setRecomendations(String recomendations) {
        this.recomendations = recomendations;
    }

    public Integer getId() {
        return id;
    }

    public float getHeight() {
        return height;
    }

    public float getWidth() {
        return width;
    }

    public float getDepth() {
        return depth;
    }

    public String getContent() {
        return content;
    }

    public String getRecomendations() {
        return recomendations;
    }

    public Integer calculateDimensions(){
        return  1;
    }
}
