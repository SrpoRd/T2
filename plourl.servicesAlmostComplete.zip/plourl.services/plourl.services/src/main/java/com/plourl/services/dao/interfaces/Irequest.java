package com.plourl.services.dao.interfaces;

import com.plourl.services.domain.genericResponseMessage;
import com.plourl.services.domain.request;

import java.sql.Connection;

public interface Irequest {

    request findRequestById(Integer id);
    genericResponseMessage storeRequest(request incomingRequest);
    genericResponseMessage updateRequest(request incomingRequest , Integer id);
    genericResponseMessage deleteRequest(Integer id);
    Connection openConnection();
    Connection closeConnection(Connection conn);

}
