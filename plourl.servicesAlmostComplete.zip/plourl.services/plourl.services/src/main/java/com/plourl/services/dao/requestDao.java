package com.plourl.services.dao;

import com.plourl.services.dao.interfaces.Irequest;
import com.plourl.services.domain.*;
import org.springframework.stereotype.Component;
import java.sql.*;
import java.util.ArrayList;


@Component
public class requestDao implements Irequest {

    @Override
    public request findRequestById(Integer id) {
        //ToDO : Consult Information On Db
        user _user = new user();
        Connection conn = openConnection();
        try {
            PreparedStatement st = conn.prepareStatement("SELECT * FROM `users` where id = "+id);
            ResultSet rs = st.executeQuery();
            while (rs.next())
            {
               _user.setId(Integer.parseInt(rs.getString("id")));
               _user.setEmail(rs.getString("correo"));
               _user.setName(rs.getString("name"));
               _user.setLastName(rs.getString("lastname"));
               _user.setPhone(rs.getString("phone"));
               _user.setMobile(rs.getString("mobile"));
               _user.setPhotoUrl(rs.getString("photo_url"));
               _user.setType(rs.getString("type"));
            }
            st = null;
            rs = null;
            st = conn.prepareStatement("SELECT * FROM `destinations` where idDESTINATIONS ="+id);
            rs = st.executeQuery();
            destination _destination = new destination();
            while (rs.next())
            {
                _destination.setId(Integer.parseInt(rs.getString("idDESTINATIONS")));
                _destination.setState(rs.getString("state"));
                _destination.setCity(rs.getString("city"));
                _destination.setAddress(rs.getString("address"));
                //_destination.setUser(rs.getString("user"));
                _destination.setLatitude(Double.parseDouble(rs.getString("lat")));
                _destination.setLongitude(rs.getDouble("long"));
            }
            st = null;
            rs = null;
            st = conn.prepareStatement("SELECT * FROM `requests` where id = "+id);
            rs = st.executeQuery();
            request _request = new request();
            while (rs.next())
            {
                _request.setId(Integer.parseInt(rs.getString("id")));
                //_request.setUser(rs.getString("user"));
                //_request.setDestination(rs.getString("destination"));
                _request.setDeparture(rs.getString("departure"));
            }
            st = null;
            rs = null;
            st = conn.prepareStatement("SELECT * FROM `packages` where id = "+id);
            rs = st.executeQuery();
            packages _packages = new packages();
            ArrayList<packages> _lpackages = new ArrayList<>();

            while (rs.next())
            {
                _packages.setId(rs.getInt("id"));
                _packages.setHeight(rs.getFloat("height"));
                _packages.setWidth(rs.getFloat("width"));
                _packages.setDepth(rs.getFloat("depth"));
                _packages.setContent(rs.getString("content"));
                _packages.setRecomendations(rs.getString("recomendation"));
                _lpackages.add(_packages);
            }
            //return object with data
            _destination.setUser(_user);
            _request.setUser(_user);
            _request.setDestination(_destination);
            _request.setPackages(_lpackages);
            //close connection
            closeConnection(conn);
            return  _request;
        } catch (SQLException e) {
            e.printStackTrace();
            return  null;
        }
    }

    @Override
    public genericResponseMessage storeRequest(request newRequest) {
        //ToDo : store request information On DB
        Connection con = openConnection();
        PreparedStatement st = null;

        try {
            StringBuilder _sb = new StringBuilder();
            st = null;

            _sb.append("INSERT INTO `users` (`id`,`name`,`lastname`,`phone`,`mobile`,`photo_url`,`type`,`correo`) ");
            _sb.append("VALUES(");
            _sb.append("'").append(newRequest.getUser().getId()).append("'").append(",");
            _sb.append("'").append(newRequest.getUser().getName()).append("'").append(",");
            _sb.append("'").append(newRequest.getUser().getLastName()).append("'").append(",");
            _sb.append("'").append(newRequest.getUser().getPhone()).append("'").append(",");
            _sb.append("'").append(newRequest.getUser().getMobile()).append("'").append(",");
            _sb.append("'").append(newRequest.getUser().getPhotoUrl()).append("'").append(",");
            _sb.append("'").append(newRequest.getUser().getType()).append("'").append(",");
            _sb.append("'").append(newRequest.getUser().getEmail()).append("'");
            _sb.append(")").append(";");
            st = con.prepareStatement(_sb.toString());
            boolean _result = st.execute();
            //endUser
            //Destination
            _sb.delete(0, _sb.length());
            st = null;
            _sb.append("INSERT INTO `destinations`(`idDESTINATIONS`,`state`,`city`,`address`,`user`,`lat`,`long`)");
            _sb.append("VALUES(");
            _sb.append("'").append(newRequest.getDestination().getId()).append("'").append(",");
            _sb.append("'").append(newRequest.getDestination().getState()).append("'").append(",");
            _sb.append("'").append(newRequest.getDestination().getCity()).append("'").append(",");
            _sb.append("'").append(newRequest.getDestination().getAddress()).append("'").append(",");
            _sb .append("'").append(newRequest.getDestination().getUser().getId()).append("'").append(",");
            _sb.append("'").append(newRequest.getDestination().getLatitude()).append("'").append(",");
            _sb.append("'").append(newRequest.getDestination().getLongitude()).append("'");
            _sb.append(")").append(";");
            st = con.prepareStatement(_sb.toString());
            _result = st.execute();
            //fin destination

            //Request
            _sb.delete(0, _sb.length());
            st= null;
            _sb.append("INSERT INTO `requests` (`id`,`user`,`departure`,`destination`)");
            _sb.append("VALUES(");
            _sb.append("'").append(newRequest.getId()).append("'").append(",");
            _sb.append("'").append(newRequest.getUser().getId()).append("'").append(",");
            _sb.append("'").append(newRequest.getDeparture()).append("'").append(",");
            _sb.append("'").append(newRequest.getDestination().getId()).append("'");
            _sb.append(")").append(";");
            st = con.prepareStatement(_sb.toString());
            _result = st.execute();
            //EndResquest
            ArrayList<packages> _lpack = new ArrayList<>();
            for (int i = 0; i < newRequest.getPackages().size() ; i++)
            {
                _sb.delete(0,_sb.length());
                _sb.append("INSERT INTO `packagess` (`id`, `height`, `width`, `depth`, `content`, `recomendation` ) ");

                _sb.append("VALUES (");
                _sb.append("'").append(newRequest.getPackages().get(i).getId())
                        .append("'").append(",").append("'")
                .append(newRequest.getPackages().get(i).getHeight())
                        .append("'").append(",").append("'")
                .append(newRequest.getPackages().get(i).getWidth())
                        .append("'").append(",").append("'")
                .append(newRequest.getPackages().get(i).getDepth())
                        .append("'").append(",").append("'")
                .append(newRequest.getPackages().get(i).getContent())
                        .append("'").append(",").append("'")
                .append(newRequest.getPackages().get(i).getRecomendations())
                .append("'").append(")").append(";");

              st =  con.prepareStatement(_sb.toString());
               _result = st.execute();
                closeConnection(con);
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        return new genericResponseMessage("Post Request successful");
    }

    @Override
    public genericResponseMessage updateRequest(request incomingRequest,Integer id) {
        //ToDo : UpdateRequest on DB
        Connection conn = openConnection();
        PreparedStatement st = null;
        StringBuilder _sb = new StringBuilder();
        _sb.append("UPDATE `users` SET");
       // _sb.append("`id`").append("=").append(incomingRequest.getUser().getId()).append(",");
        _sb.append("`name`").append(" = ").append("'").append(incomingRequest.getUser().getName().toString()).append("'").append(",");
        _sb.append("`lastname`").append(" = ").append("'").append(incomingRequest.getUser().getLastName().toString()).append("'").append(",");
        _sb.append("`phone`").append(" = ").append("'").append(incomingRequest.getUser().getPhone().toString()).append("'").append(",");
        _sb.append("`mobile`").append(" = ").append("'").append(incomingRequest.getUser().getMobile().toString()).append("'").append(",");
        _sb.append("`photo_url`").append(" = ").append("'").append(incomingRequest.getUser().getPhotoUrl().toString()).append("'").append(",");
        _sb.append("`type`").append(" = ").append("'").append(incomingRequest.getUser().getType().toString()).append("'").append(",");
        _sb.append("`correo`").append(" = ").append("'").append(incomingRequest.getUser().getEmail().toString()).append("'").append(" ");
        _sb.append(" WHERE  ").append("id").append("=").append(id);
        try {
            st = conn.prepareStatement(_sb.toString());
            int _result = st.executeUpdate();
            //destinations
            st = null ;
            _sb.delete(0, _sb.length());
            _sb.append("UPDATE `destinations` SET");
           // _sb.append("idDESTINATIONS").append("=").append("'").append(incomingRequest.getDestination().getId().toString()).append("'").append(",");
            _sb.append("`state` ").append(" = ").append("'").append(incomingRequest.getDestination().getState().toString()).append("'").append(",");
            _sb.append("`city`").append(" = ").append("'").append(incomingRequest.getDestination().getCity().toString()).append("'").append(",");
            _sb.append("`address`").append(" = ").append("'").append(incomingRequest.getDestination().getAddress().toString()).append("'").append(",");
            _sb.append("`user`").append("=").append("'").append(incomingRequest.getDestination().getUser().getId()).append("'").append(",");
            _sb.append("`lat`").append(" = ").append("").append(incomingRequest.getDestination().getLatitude()).append("").append(",");
            _sb.append("`long`").append(" = ").append("").append(incomingRequest.getDestination().getLongitude()).append("").append(" ");
            _sb.append("WHERE ").append("idDESTINATIONS").append(" = ").append(id);
            st = conn.prepareStatement(_sb.toString());
            _result = st.executeUpdate();
            //destinations
            st = null ;
            //request
            _sb.delete(0, _sb.length());
            _sb.append("UPDATE `requests` SET ");
           // _sb.append("`id`").append("=").append("'").append(incomingRequest.getId().toString()).append("'").append(",");
            _sb.append("`user`").append("=").append("'").append(incomingRequest.getUser().getId().toString()).append("'").append(",");
            _sb.append("`departure`").append("=").append("'").append(incomingRequest.getDeparture().toString()).append("'").append(",");
            _sb.append("`destination`").append("=").append("'").append(incomingRequest.getDestination().getId().toString()).append("'").append(" ");
            _sb.append("WHERE ").append("id").append(" = ").append(id);
            st = conn.prepareStatement(_sb.toString());
            _result = st.executeUpdate();
            st = null;
            //packages
            ArrayList<packages> _lpack = new ArrayList<>();
            for (int i = 0; i < incomingRequest.getPackages().size() ; i++)
            {
                _sb.delete(0, _sb.length());
                _sb.append("UPDATE `packagess` SET ");
                _sb.append("`content`").append(" = ").append("'").append(incomingRequest.getPackages().get(i).getContent().toString()).append("'").append(",");
                _sb.append("`depth`").append(" = ").append("'").append(incomingRequest.getPackages().get(i).getDepth()).append("'").append(",");
                _sb.append("`height`").append(" = ").append("'").append(incomingRequest.getPackages().get(i).getHeight()).append("'").append(",");
                _sb.append("`recomendation`").append(" = ").append("'").append(incomingRequest.getPackages().get(i).getRecomendations().toString()).append("'").append(",");
                //_sb.append("`request`").append(" = ").append("'").append(incomingRequest.getPackages().get(i).ge)
                _sb.append("`width`").append(" = ").append("'").append(incomingRequest.getPackages().get(i).getWidth()).append("'").append(" ");
                _sb.append(" WHERE ").append("id").append(" = ").append(id);
                st = conn.prepareStatement(_sb.toString());
                _result = st.executeUpdate();
            }

            //packages

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return new genericResponseMessage("Put request successful");
    }

    @Override
    public genericResponseMessage deleteRequest(Integer id) {
        //ToDo : Delete Request on DB
        return new genericResponseMessage("Delete request successful");
    }

    @Override
    public Connection openConnection() {

        //ToDo : Read parameters by config File
        String _jdbcDriver = "com.mysql.jdbc.Driver";
        String _dbUrl = "jdbc:mysql://localhost/plourl";
        String user = "root";
        String pass =  "";
        Connection conn = null;
        try {
            Class.forName(_jdbcDriver);
            conn = DriverManager.getConnection(_dbUrl,user,pass);
            //PreparedStatement st = conn.prepareStatement(
              //      "INSERT INTO `users` (`id`, `name`, `lastname`, `phone`, `mobile`, `photo_url`, `type`) VALUES ('4', 'Santiago', 'Res', '1234', '2344', " +
                //            "'12233', '31');");
            //int result = st.executeUpdate();
        }catch (Exception ex)
        {
            return  null;
        }

        return  conn;
    }

    @Override
    public Connection closeConnection(Connection conn)   {

        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

}
