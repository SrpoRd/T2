package com.plourl.services.domain;

public class user {
    private  Integer id;
    private  String name;
    private  String lastName;
    private  String phone;
    private  String mobile;
    private  String photoUrl;
    private  String email;
    private  String password;
    private  String type;

    public user(Integer id, String name, String lastName, String phone, String mobile, String photoUrl, String email, String password, String type) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
        this.phone = phone;
        this.mobile = mobile;
        this.photoUrl = photoUrl;
        this.email = email;
        this.password = password;
        this.type = type;
    }
    public  user(){}

    public void setId(Integer id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public void setPhotoUrl(String photoUrl) {
        this.photoUrl = photoUrl;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getMobile() {
        return mobile;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getType() {
        return type;
    }

    public  void changeTypeUser(String user)
    {
        //ToDO
    }
}
