package com.plourl.services.dao.interfaces;

import com.plourl.services.domain.genericResponseMessage;
import com.plourl.services.domain.request;

public interface Irequest {

    request findRequestById(Integer id);
    genericResponseMessage storeRequest(request incomingRequest);
    genericResponseMessage updateRequest(request incomingRequest);
    genericResponseMessage deleteRequest(Integer id);

}
