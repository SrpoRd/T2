package com.plourl.services.dao;

import com.plourl.services.dao.interfaces.Irequest;
import com.plourl.services.domain.*;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Date;

@Component
public class requestDao implements Irequest {
    @Override
    public request findRequestById(Integer id) {
        //ToDO : Consult Information On Db
        user _user = new user( 1,"santiago","Restrepo","4550","8545","http:null",
                "notiene@xyz.com","123","user");

        destination _destination = new destination(1,"Colombia","Medellin","calle falsa ",_user,
                4789,852);

        packages _packages = new packages(1,2550,4520,1234,"Galletas","si");
        ArrayList<packages> _lpack = new ArrayList<>();
        _lpack.add(_packages);
        _lpack.add(_packages);
        Date _date = new Date();
        return  new request(1,_user,"2017-10-12",_destination,_lpack);
       // return null;
    }

    @Override
    public genericResponseMessage storeRequest(request newRequest) {
        //ToDo : store request information On DB
        return new genericResponseMessage("Post Request successful");
    }

    @Override
    public genericResponseMessage updateRequest(request incomingRequest) {
        //ToDo : UpdateRequest on DB

        return new genericResponseMessage("Put request successful");
    }

    @Override
    public genericResponseMessage deleteRequest(Integer id) {
        //ToDo : Delete Request on DB
        return new genericResponseMessage("Delete request successful");
    }

}
