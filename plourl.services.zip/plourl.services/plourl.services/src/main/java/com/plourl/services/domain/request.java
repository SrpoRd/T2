package com.plourl.services.domain;

import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

public class request {
 private  Integer id;
 private  user user;
 private  String departure;
 private  destination destination;
 private  List<packages> packages;


    public  request(request nrequest)
    {
        this.user = nrequest.user;
        this.departure = nrequest.departure;
        this.destination = nrequest.destination;
        this.packages = nrequest.packages;
        this.id = nrequest.id;
    }
    public  request(){}

    public request(Integer id, com.plourl.services.domain.user user, String departure, com.plourl.services.domain.destination destination, List<com.plourl.services.domain.packages> packages) {
        this.id = id;
        this.user = user;
        this.departure = departure;
        this.destination = destination;
        this.packages = packages;
    }


    public Integer getId()  {  return id;   }

    public com.plourl.services.domain.user getUser() {
        return user;
    }

    public String getDeparture() {
        return departure;
    }

    public com.plourl.services.domain.destination getDestination() {
        return destination;
    }

    public List<com.plourl.services.domain.packages> getPackages() {
        return packages;
    }

    @Override
    public String toString() {
        return "request{" +
                "id=" + id +
                ", user=" + user +
                ", departure='" + departure + '\'' +
                ", destination=" + destination +
                ", packages=" + packages +
                '}';
    }
}
