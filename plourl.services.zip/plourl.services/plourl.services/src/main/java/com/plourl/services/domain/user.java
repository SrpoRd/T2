package com.plourl.services.domain;

public class user {
    private  Integer id;
    private  String name;
    private  String lastName;
    private  String phone;
    private  String mobile;
    private  String photoUrl;
    private  String email;
    private  String password;
    private  String type;

    public user(Integer id, String name, String lastName, String phone, String mobile, String photoUrl, String email, String password, String type) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
        this.phone = phone;
        this.mobile = mobile;
        this.photoUrl = photoUrl;
        this.email = email;
        this.password = password;
        this.type = type;
    }
    public  user(){}

    public Integer getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getLastName() {
        return lastName;
    }

    public String getPhone() {
        return phone;
    }

    public String getMobile() {
        return mobile;
    }

    public String getPhotoUrl() {
        return photoUrl;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public String getType() {
        return type;
    }

    public  void changeTypeUser(String user)
    {
        //ToDO
    }
}
