package com.plourl.services.domain;

public class destination {
    private  Integer id;
    private  String state;
    private  String city;
    private  String address;
    private  user user;
    private  double latitude;
    private  double longitude;

    public destination(Integer id, String state, String city, String address, com.plourl.services.domain.user user, double latitude, double longitude) {
        this.id = id;
        this.state = state;
        this.city = city;
        this.address = address;
        this.user = user;
        this.latitude = latitude;
        this.longitude = longitude;
    }
    public  destination(){}

    public Integer getId() {
        return id;
    }

    public String getState() {
        return state;
    }

    public String getCity() {
        return city;
    }

    public String getAddress() {
        return address;
    }

    public com.plourl.services.domain.user getUser() {
        return user;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }
}
