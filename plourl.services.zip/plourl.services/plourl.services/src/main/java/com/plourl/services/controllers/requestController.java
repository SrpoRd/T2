package com.plourl.services.controllers;

import com.plourl.services.TestingService.Greeting;
import com.plourl.services.dao.interfaces.Irequest;
import com.plourl.services.domain.*;
import com.sun.net.httpserver.HttpsParameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import javax.naming.Name;
import java.awt.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@RestController
public class requestController {

    @Autowired
    private Irequest requestDao;

    @RequestMapping(name = "/getRequestInformation" , method = RequestMethod.GET)
    public request Request(@RequestParam(value = "id" , defaultValue = "1")Integer id)
    {
       return requestDao.findRequestById(id);
    }

    @RequestMapping(name = "/createRequest",method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    public genericResponseMessage receiverMessage(@RequestBody request incomingRequest)
    {
        //requestDao.storeRequest(newRequest);
        return  requestDao.storeRequest(incomingRequest);
    }

    @RequestMapping(name = "/updateRequest",method = RequestMethod.PUT,consumes = MediaType.APPLICATION_JSON_VALUE)
    public genericResponseMessage updateRequest(@RequestBody request incomingRequest)
    {
       return  requestDao.updateRequest(incomingRequest);
    }
    @RequestMapping(name = "/deleteRequest",method = RequestMethod.DELETE,consumes = MediaType.APPLICATION_JSON_VALUE)
    public  genericResponseMessage deleteRequest(@RequestParam(value = "id",required = true)Integer id)
    {
        return  requestDao.deleteRequest(id);
    }
}
