package com.plourl.services.domain;

public class genericResponseMessage {
    private   String result;

    public genericResponseMessage(String result) {
        this.result = result;
    }

    public String getResult() {
        return result;
    }
    public  genericResponseMessage(){}
}
